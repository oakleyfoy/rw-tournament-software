"""
Tests for preventing duplicate match generation.

Verifies:
- Events are not duplicated in the generation list
- No duplicate match_codes are generated
- Build Schedule is safe to call multiple times
- No UNIQUE constraint errors occur
"""

import json
import pytest
from datetime import date, time
from sqlmodel import Session, select, func

from app.models.event import Event
from app.models.match import Match
from app.models.schedule_slot import ScheduleSlot
from app.models.schedule_version import ScheduleVersion
from app.models.team import Team
from app.models.tournament import Tournament
from app.models.tournament_time_window import TournamentTimeWindow
from app.services.schedule_orchestrator import build_schedule_v1


@pytest.fixture
def multi_event_setup(session):
    """Set up a tournament with multiple events to test duplicate prevention."""
    tournament = Tournament(
        name="Multi-Event Test Tournament",
        location="Test Location",
        start_date=date(2026, 5, 1),
        end_date=date(2026, 5, 3),
        timezone="America/New_York",
        court_names="1,2,3,4,5,6",
        use_time_windows=True,
    )
    session.add(tournament)
    session.flush()

    events = []
    for name, team_count in [
        ("Mixed Doubles", 4),
        ("Women's A", 6),
        ("Women's B", 4),
    ]:
        event = Event(
            tournament_id=tournament.id,
            name=name,
            category="mixed" if "Mixed" in name else "women",
            team_count=team_count,
            draw_status="final",
            draw_plan_json=json.dumps({
                "version": "1.0",
                "template_type": "RR_ONLY",
                "wf_rounds": 0,
            }),
            wf_block_minutes=60,
            standard_block_minutes=105,
        )
        session.add(event)
        session.flush()

        for t in range(team_count):
            team = Team(
                event_id=event.id,
                name=f"{name} Team {t+1}",
                seed=t + 1,
            )
            session.add(team)

        events.append(event)
    session.flush()

    for day_offset in range(3):
        window = TournamentTimeWindow(
            tournament_id=tournament.id,
            day_date=date(2026, 5, 1 + day_offset),
            start_time=time(8, 0),
            end_time=time(18, 0),
            block_minutes=105,
            courts_available=6,
            is_active=True,
        )
        session.add(window)
    session.flush()

    version = ScheduleVersion(
        tournament_id=tournament.id,
        status="draft",
        version_number=1,
    )
    session.add(version)
    session.flush()

    session.commit()

    return {
        "tournament_id": tournament.id,
        "event_ids": [e.id for e in events],
        "version_id": version.id,
        "session": session,
    }


class TestNoDuplicateEventGeneration:
    """Tests for duplicate match generation prevention."""

    def test_no_duplicate_match_codes_on_build(self, multi_event_setup):
        """Build Schedule should generate unique match codes for all events."""
        setup = multi_event_setup
        session = setup["session"]

        result = build_schedule_v1(
            session=session,
            tournament_id=setup["tournament_id"],
            version_id=setup["version_id"],
            clear_existing=True,
            inject_teams=False,
        )

        assert result.summary.matches_generated > 0, "No matches generated"

        matches = session.exec(
            select(Match).where(Match.schedule_version_id == setup["version_id"])
        ).all()
        match_codes = [m.match_code for m in matches]

        unique_codes = set(match_codes)
        assert len(unique_codes) == len(match_codes), (
            f"Duplicate match_codes detected: {[c for c in match_codes if match_codes.count(c) > 1]}"
        )

    def test_rebuild_does_not_create_duplicates(self, multi_event_setup):
        """Rebuilding schedule should not create duplicate matches."""
        setup = multi_event_setup
        session = setup["session"]

        result1 = build_schedule_v1(
            session=session,
            tournament_id=setup["tournament_id"],
            version_id=setup["version_id"],
            clear_existing=True,
        )
        count1 = result1.summary.matches_generated

        matches1 = session.exec(
            select(Match).where(Match.schedule_version_id == setup["version_id"]).order_by(Match.id)
        ).all()
        codes1 = [m.match_code for m in matches1]

        result2 = build_schedule_v1(
            session=session,
            tournament_id=setup["tournament_id"],
            version_id=setup["version_id"],
            clear_existing=True,
        )
        count2 = result2.summary.matches_generated

        matches2 = session.exec(
            select(Match).where(Match.schedule_version_id == setup["version_id"]).order_by(Match.id)
        ).all()
        codes2 = [m.match_code for m in matches2]

        assert count1 == count2, f"Match count changed: {count1} -> {count2}"
        assert codes1 == codes2, "Match codes changed after rebuild"
        assert len(set(codes2)) == len(codes2), "Duplicate match_codes after rebuild"

    def test_each_event_processed_exactly_once(self, multi_event_setup):
        """Each event should have matches generated exactly once."""
        setup = multi_event_setup
        session = setup["session"]

        build_schedule_v1(
            session=session,
            tournament_id=setup["tournament_id"],
            version_id=setup["version_id"],
            clear_existing=True,
        )

        for event_id in setup["event_ids"]:
            count = session.exec(
                select(func.count(Match.id)).where(
                    Match.schedule_version_id == setup["version_id"],
                    Match.event_id == event_id,
                )
            ).one()

            event = session.get(Event, event_id)

            assert count > 0, f"Event {event.name} (id={event_id}) has no matches"

            event_matches = session.exec(
                select(Match).where(
                    Match.schedule_version_id == setup["version_id"],
                    Match.event_id == event_id,
                )
            ).all()
            event_codes = [m.match_code for m in event_matches]
            unique_event_codes = set(event_codes)

            assert len(unique_event_codes) == len(event_codes), (
                f"Event {event.name} has duplicate match_codes: "
                f"{[c for c in event_codes if event_codes.count(c) > 1]}"
            )

    def test_no_integrity_error_on_triple_build(self, multi_event_setup):
        """Building schedule three times should never raise IntegrityError."""
        setup = multi_event_setup
        session = setup["session"]

        result1 = build_schedule_v1(
            session=session,
            tournament_id=setup["tournament_id"],
            version_id=setup["version_id"],
            clear_existing=True,
        )

        result2 = build_schedule_v1(
            session=session,
            tournament_id=setup["tournament_id"],
            version_id=setup["version_id"],
            clear_existing=True,
        )

        result3 = build_schedule_v1(
            session=session,
            tournament_id=setup["tournament_id"],
            version_id=setup["version_id"],
            clear_existing=True,
        )

        assert result1.summary.matches_generated > 0
        assert result2.summary.matches_generated == result1.summary.matches_generated
        assert result3.summary.matches_generated == result1.summary.matches_generated

        final_count = session.exec(
            select(func.count(Match.id)).where(Match.schedule_version_id == setup["version_id"])
        ).one()
        assert final_count == result1.summary.matches_generated
